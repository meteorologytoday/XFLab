#ifdef X_OFFSET_H
#ifndef X_OFFSET_CPP
#define X_OFFSET_CPP

namespace X {


}

#endif
#endif
