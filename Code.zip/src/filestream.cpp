#ifdef X_FILESTREAM_H
#ifndef X_FILESTREAM_CPP
#define X_FILESTREAM_CPP

namespace X {
    




}

#endif
#endif
