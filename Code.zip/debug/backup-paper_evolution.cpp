#define _USE_MATH_DEFINES
#include <cmath>

#include <fstream>
#include <iostream>

#include <string>
#include <sstream>

#define X_INCLUDE_IO
#define X_INCLUDE_DIM2
#define X_INCLUDE_FFTW
#define X_INCLUDE_GNUPLOT
#define X_FFTW_MAGIC_DOUBLE
#include "xdmlab"

#define DD(x) static_cast<xsize>(DATA::x)
#define WW(x) static_cast<xsize>(WAVE::x)
#define SS(x) static_cast<xsize>(SET::x)

typedef double T;

using namespace X;
using namespace X::FFTW;
using namespace X::GNUPLOT;
using namespace std;

const T vort_nu = 50;
const T tracer_nu = 25;
const xsize D0 = 768;
const xsize D1 = 768;
const double delta_t = 3.5;
const xsize total_time = 3600 * 1.5;
const xsize final_timestep = (xsize) (total_time/delta_t);
const xsize recording_timestep = 10;
const T L0 = 600000;
const T L1 = 600000;
const T filter0 = 256;
const T filter1 = 256;
const T filter = 255;


enum class DATA : xsize {
    vort = 0, vortgdx, vortgdy, u, v, vortlap, vort_nonlin, vort_output,
    tracer, tracergdx, tracergdy, tracerlap, tracer_nonlin, tracer_output,
    SIZE
};

enum class WAVE : xsize {
    vort = 0, stream, u, v, vortgdx, vortgdy, vortlap, vorttmp, vort_nonlin, q1, q2, q3, q4, vort_output, 
    tracer, tracergdx, tracergdy, tracerlap, tracertmp, tracer_nonlin, tracer_q1, tracer_q2, tracer_q3, tracer_q4, tracer_output,
    nonlin_mask, wnx, wny, dealiasing_mask,
    SIZE
};

const xsize WAVETABLESIZE = fftw_wave_table_size(D0,D1);


enum class RK4_STAGE : xsize { s1, s2, s3, s4 };

enum class SET : xsize {
    r = 0, alpha,
    SIZE
};



void printr(T * nums, xsize n0, xsize n1);
void printc(fftw_complex * nums, xsize n0, xsize n1);

int main() {
    cout << "# Program start" << endl << flush;

    Enumerator2<T,D0,D1> enu_data;
    Enumerator1<FFTW_COMPLEX, WAVETABLESIZE> enu_wave;
    Vector<T,D0> x;
    Vector<T,D1> y;
    
    cout << "Allocating matrix..." << endl << flush;

    Matrix<T,2,D0*D1> xxyy;
    Util::linspace2(x, (T) 0, L0);
    Util::linspace2(y, (T) 0, L1);

    cout << x << endl;
    cout << "Set meshgrid..." << endl << flush;
    Util::set2DMeshgrid(xxyy,x,y);

    cout << "Meshgrid set." << endl << flush;
    Field2DIndex2<T,D0,D1, DD(SIZE)> f; f.setGrid(xxyy);
    Field2DIndex2<T,D0,D1, SS(SIZE)> setting; setting.setGrid(xxyy);


    T step0 = (2 * M_PI) / D0;
    T step1 = (2 * M_PI) / D1;

    cout << "Setting vorticity..." << endl << flush;

    T centx = L0/2;
    T centy = L1/2;

    Util::distance(setting,centx,centy, SS(r));


    T epsilon = 0.7;
    T lambda = 2.0;
    T r_i = 30000;
    T r_o = 60000;
    T lim0 = 1 - pow(epsilon,2);
    T zeta0 = 0.005;
    enu_data.each_index_offset([&] (xsize i, xsize j) {
            T dx = xxyy(0,i,j) - centx;
            T r = setting(SS(r),i,j);


            // to prevent r = 0 situation
            if ( r < lim0 ) {
                f(DD(vort), i, j) = zeta0;
                return;
            }


            T alpha = (1 - pow(epsilon,2)) / sqrt( 1 - pow( epsilon * dx/r, 2));

            if(r < r_i * alpha) {
                f(DD(vort), i, j) = zeta0;
                return;
            } else if(r > r_o * alpha) {
                f(DD(vort), i, j) = 0;
                return;
            }


            T r_prime = (r/alpha - r_i) / (r_o - r_i);
            f(DD(vort), i, j) = zeta0 * (1 - exp(- (lambda / r_prime) * exp (1/(r_prime - 1))));
            
    });

    T r_a = 50000;
    T c_0 = 1000;
    enu_data.each_index([&] (xsize i, xsize j) {
            T r = setting(SS(r),i,j);
            f(DD(tracer),i,j) = c_0 * exp(-pow(r/r_a,2)) ;
    });

    string vort_filename("init_vort");
    string tracer_filename("init_tracer");
    output_field(vort_filename.c_str(), f[DD(vort)].getPtr(), x.getPtr(), y.getPtr(), D0, D1);
    output_field(tracer_filename.c_str(), f[DD(tracer)].getPtr(), x.getPtr(), y.getPtr(), D0, D1);

    cout << "Allocating wavetable..." << endl << flush;


    Field<FFTW_COMPLEX, 1, WAVETABLESIZE, WW(SIZE)> w;
    //fftw_set_wavenumber2(w(WW[wnx].getPtr(), w(WW[wnx].getPtr(), D0, D1)));

    cout << "Making fftw plans..." << endl << flush;
    // fftw plans
    // vort
    fftw_plan vort_sink =        fftw_plan_dft_r2c_2d(D0, D1, f[DD(vort)].getPtr(),  w[WW(vort)].getPtr(), FFTW_ESTIMATE);
    fftw_plan vort_nonlin_sink = fftw_plan_dft_r2c_2d(D0, D1, f[DD(vort_nonlin)].getPtr(),  w[WW(vort_nonlin)].getPtr(), FFTW_ESTIMATE);
    
    fftw_plan vortgdx_rise =     fftw_plan_dft_c2r_2d(D0, D1, w[WW(vortgdx)].getPtr(), f[DD(vortgdx)].getPtr(), FFTW_ESTIMATE);
    fftw_plan vortgdy_rise =     fftw_plan_dft_c2r_2d(D0, D1, w[WW(vortgdy)].getPtr(), f[DD(vortgdy)].getPtr(), FFTW_ESTIMATE);
    fftw_plan u_rise =           fftw_plan_dft_c2r_2d(D0, D1, w[WW(u)].getPtr(),       f[DD(u)].getPtr(), FFTW_ESTIMATE);
    fftw_plan v_rise =           fftw_plan_dft_c2r_2d(D0, D1, w[WW(v)].getPtr(),       f[DD(v)].getPtr(), FFTW_ESTIMATE);
    fftw_plan vort_output_rise = fftw_plan_dft_c2r_2d(D0, D1, w[WW(vort_output)].getPtr(),    f[DD(vort_output)].getPtr(), FFTW_ESTIMATE);

    // fftw plans
    // tracer
    fftw_plan tracer_sink        = fftw_plan_dft_r2c_2d(D0, D1, f[DD(tracer)].getPtr(),  w[WW(tracer)].getPtr(), FFTW_ESTIMATE);
    fftw_plan tracer_nonlin_sink = fftw_plan_dft_r2c_2d(D0, D1, f[DD(tracer_nonlin)].getPtr(),  w[WW(tracer_nonlin)].getPtr(), FFTW_ESTIMATE);
    
    fftw_plan tracergdx_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracergdx)].getPtr(), f[DD(tracergdx)].getPtr(), FFTW_ESTIMATE);
    fftw_plan tracergdy_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracergdy)].getPtr(), f[DD(tracergdy)].getPtr(), FFTW_ESTIMATE);
    fftw_plan tracerlap_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracerlap)].getPtr(), f[DD(tracerlap)].getPtr(), FFTW_ESTIMATE);
    fftw_plan tracer_output_rise = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracer_output)].getPtr(),    f[DD(tracer_output)].getPtr(), FFTW_ESTIMATE);

    cout << "Making fftw plans done" << endl << flush;
    
    // filter
    //

//    cout << "filter0 = " << filter0 << ", filter1 = " << filter1;
    for(xsize i=0;i<D0;++i) {
        for(xsize j=0; j<(D1/2+1); ++j) {
            T k = mapWavenumber(D0,i);
            T l = mapWavenumber(D1,j);
            
            if(mapWavenumber(D0,i) > filter0 || mapWavenumber(D0,i) < -filter0 || mapWavenumber(D1,j) > filter1 || mapWavenumber(D1,j) < -filter1) {
            //if(sqrt(k*k + l*l) > filter) {
                w(WW(dealiasing_mask),OFFSET2(D0,(D1/2+1),i,j))[0] = 0;
                w(WW(dealiasing_mask),OFFSET2(D0,(D1/2+1),i,j))[1] = 0;
            } else {
                w(WW(dealiasing_mask),OFFSET2(D0,(D1/2+1),i,j))[0] = 1;
                w(WW(dealiasing_mask),OFFSET2(D0,(D1/2+1),i,j))[1] = 0;
            }
        }
    }


    // Evolution starts ~~
    
    fftw_execute(vort_sink);

    xsize rk4_counter_vort, rk4_counter_tracer;
    T sum_vort = 0;
    T sum_tracer = 0;
    cout << "Entering for loop" << endl << flush;
    for(xsize timestep = 1; timestep <= final_timestep; ++ timestep ) {
        cout << "timestep : " << ( timestep * delta_t ) << ". ";
        sum_vort = 0;
        sum_tracer = 0;

        enu_wave.each_index([&] (xsize i) { 
                w(WW(vorttmp),i)[0] = w(WW(vort),i)[0];
                w(WW(vorttmp),i)[1] = w(WW(vort),i)[1];
                w(WW(tracertmp),i)[0] = w(WW(tracer),i)[0];
                w(WW(tracertmp),i)[1] = w(WW(tracer),i)[1];
 
    });
        
        for(xsize rk_stage = 0; rk_stage < 4; ++rk_stage) {


            diff2(0, 1, w[WW(vort)].getPtr(), w[WW(vortgdx)].getPtr(), D0, D1, L0, L1);
            diff2(1, 1, w[WW(vort)].getPtr(), w[WW(vortgdy)].getPtr(), D0, D1, L0, L1);

            laplacian(w[WW(vort)].getPtr(), w[WW(vortlap)].getPtr(), D0, D1, L0, L1);
            ipoisson(w[WW(vort)].getPtr(), w[WW(stream)].getPtr(), D0, D1, L0, L1);

            diff2(0, 1, w[WW(stream)].getPtr(), w[WW(v)].getPtr(), D0, D1, L0, L1);
            diff2(1, 1, w[WW(stream)].getPtr(), w[WW(u)].getPtr(), D0, D1, L0, L1);

            // de-aliasing u,v,vortgdx,vortgdy
            enu_wave.each_index([&](xsize i) {
                if(w(WW(dealiasing_mask),i)[0] == 0) {
                    w(WW(u),i)[0] = 0;
                    w(WW(u),i)[1] = 0;
                    w(WW(v),i)[0] = 0;
                    w(WW(v),i)[1] = 0;
                    w(WW(vortgdx),i)[0] = 0;
                    w(WW(vortgdx),i)[1] = 0;
                    w(WW(vortgdy),i)[0] = 0;
                    w(WW(vortgdy),i)[1] = 0;
                    
                }
                    
            });
            //f[WW(u)].mulBy(f[WW(dealiasing_mask)]);
            //f[WW(v)].mulBy(f[WW(dealiasing_mask)]);
            
            //f[WW(vortgdx)].mulBy(f[WW(dealiasing_mask)]);
            //f[WW(vortgdy)].mulBy(f[WW(dealiasing_mask)]);
            
            fftw_execute(vortgdx_rise); 
            fftw_execute(vortgdy_rise); 
            fftw_execute(u_rise); 
            fftw_execute(v_rise); 

            f[DD(vortgdx)].divBy(D0*D1);
            f[DD(vortgdy)].divBy(D0*D1);
            f[DD(u)].divBy(D0*D1);
            f[DD(v)].divBy(D0*D1);



            // get vortgdx * u + vortgdy * v   
            enu_data.each_index([&] (xsize i, xsize j) {
                f(DD(vort_nonlin),i,j) = - f(DD(vortgdx),i,j) * f(DD(u),i,j) + f(DD(vortgdy),i,j) * f(DD(v),i,j);
            });

            fftw_execute(vort_nonlin_sink);


            // Now we start dealing with tracer...
            //fftw_execute(tracer_sink);
            //diff2(0, 1, w[WW(tracer)].getPtr(), w[WW(tracergdx)].getPtr(), D0, D1, L0, L1);
            //diff2(1, 1, w[WW(tracer)].getPtr(), w[WW(tracergdy)].getPtr(), D0, D1, L0, L1);

            //laplacian(w[WW(tracer)].getPtr(), w[WW(tracerlap)].getPtr(), D0, D1, L0, L1);

            // dealiasing...
            //f[WW(tracergdx)].mulBy(f[WW(dealiasing_mask)]);
            //f[WW(tracergdy)].mulBy(f[WW(dealiasing_mask)]);
            
            //fftw_execute(tracergdx_rise);
            //fftw_execute(tracergdy_rise);

            //f[DD(tracergdx)].divBy(D0*D1);
            //f[DD(tracergdy)].divBy(D0*D1);
            
     
            // get vortgdx * u + vortgdy * v   
            //enu_data.each_index([&] (xsize i, xsize j) {
            //    f(DD(tracer_nonlin),i,j) = - f(DD(tracergdx),i,j) * f(DD(u),i,j) + f(DD(tracergdy),i,j) * f(DD(v),i,j);
            //});

            //fftw_execute(tracer_nonlin_sink);

            switch(rk_stage) {
                case 0:
                    rk4_counter_vort = WW(q1);
                    rk4_counter_tracer = WW(tracer_q1);
                    break;
                case 1:
                    rk4_counter_vort = WW(q2);
                    rk4_counter_tracer = WW(tracer_q2);
                    break;
                case 2:
                    rk4_counter_vort = WW(q3);
                    rk4_counter_tracer = WW(tracer_q3);
                    break;
                case 3:
                    rk4_counter_vort = WW(q4);
                    rk4_counter_tracer = WW(tracer_q4);
                    break;
            }


            enu_wave.each_index( [&] (xsize i) { 
                    w(rk4_counter_vort,i)[0]   = w(WW(vortlap),i)[0] * vort_nu - w(WW(vort_nonlin),i)[0];
                    w(rk4_counter_vort,i)[1]   = w(WW(vortlap),i)[1] * vort_nu - w(WW(vort_nonlin),i)[1];

              //      w(rk4_counter_tracer,i)[0] = w(WW(tracerlap),i)[0] * tracer_nu - w(WW(tracer_nonlin),i)[0];
              //      w(rk4_counter_tracer,i)[1] = w(WW(tracerlap),i)[1] * tracer_nu - w(WW(tracer_nonlin),i)[1];
                    

                    switch(rk_stage) {
                    case 0:
                        w(WW(vorttmp),i)[0] = w(WW(vort),i)[0] + (delta_t/2) * w(rk4_counter_vort,i)[0]; 
                        w(WW(vorttmp),i)[1] = w(WW(vort),i)[1] + (delta_t/2) * w(rk4_counter_vort,i)[1]; 
    
               //         w(WW(tracertmp),i)[0] = w(WW(tracer),i)[0] + (delta_t/2) * w(rk4_counter_tracer,i)[0]; 
               //         w(WW(tracertmp),i)[1] = w(WW(tracer),i)[1] + (delta_t/2) * w(rk4_counter_tracer,i)[1]; 
                    break;
                    case 1:
                        w(WW(vorttmp),i)[0] = w(WW(vort),i)[0] + (delta_t/2) * w(rk4_counter_vort,i)[0];
                        w(WW(vorttmp),i)[1] = w(WW(vort),i)[1] + (delta_t/2) * w(rk4_counter_vort,i)[1];
                        
             //           w(WW(tracertmp),i)[0] = w(WW(tracer),i)[0] + (delta_t/2) * w(rk4_counter_tracer,i)[0]; 
             //           w(WW(tracertmp),i)[1] = w(WW(tracer),i)[1] + (delta_t/2) * w(rk4_counter_tracer,i)[1]; 
                    break;
                    case 2:
                        w(WW(vorttmp),i)[0] = w(WW(vort),i)[0] + delta_t * w(rk4_counter_vort,i)[0];
                        w(WW(vorttmp),i)[1] = w(WW(vort),i)[1] + delta_t * w(rk4_counter_vort,i)[1];
                        
            //            w(WW(tracertmp),i)[0] = w(WW(tracer),i)[0] + delta_t * w(rk4_counter_tracer,i)[0]; 
            //            w(WW(tracertmp),i)[1] = w(WW(tracer),i)[1] + delta_t * w(rk4_counter_tracer,i)[1]; 
                    break;
                    case 3:
                        w(WW(vort),i)[0] +=  delta_t * ( (w(WW(q1),i)[0]/6) + (w(WW(q2),i)[0]/3) + (w(WW(q3),i)[0]/3) + (w(WW(q4),i)[0]/6) );
                        w(WW(vort),i)[1] +=  delta_t * ( (w(WW(q1),i)[1]/6) + (w(WW(q2),i)[1]/3) + (w(WW(q3),i)[1]/3) + (w(WW(q4),i)[1]/6) );
                        
              //          w(WW(tracer),i)[0] += delta_t * ( (w(WW(tracer_q1),i)[0]/6) + (w(WW(tracer_q2),i)[0]/3) + (w(WW(tracer_q3),i)[0]/3) + (w(WW(tracer_q4),i)[0]/6) );
              //          w(WW(tracer),i)[1] += delta_t * ( (w(WW(tracer_q1),i)[1]/6) + (w(WW(tracer_q2),i)[1]/3) + (w(WW(tracer_q3),i)[1]/3) + (w(WW(tracer_q4),i)[1]/6) );
                    break;
                    }

            }); 
        }


//        cout << " sum of vort = " << sum_vort << ", sum of tracer = " << sum_tracer; 
        if(timestep % recording_timestep == 0) {
//            enu_data.each_index([&] (xsize i, xsize j) { f(DD(vort_output),i,j) = 0; });
//
//
            enu_wave.each_index( [&] (xsize i) {
                w(WW(vort_output),i)[0] = w(WW(vort),i)[0];
                w(WW(vort_output),i)[1] = w(WW(vort),i)[1];
            });
 
 //           enu_wave.each_index( [&] (xsize i) {
 //               w(WW(tracer_output),i)[0] = w(WW(tracer),i)[0];
 //               w(WW(tracer_output),i)[1] = w(WW(tracer),i)[1];
//            });
            
            fftw_execute(vort_output_rise);
//            fftw_execute(tracer_output_rise);
            f[DD(vort_output)].divBy(D0*D1);
//            f[DD(tracer_output)].divBy(D0*D1);
//
            T sum_vort = 0;
            enu_data.each_index([&] (xsize i, xsize j){
                sum_vort += f(DD(vort_output),i,j);
            });
            cout << "sum of vort : " << sum_vort << endl;
            int t = timestep * delta_t;
            cout << "   Recording...";
            std::stringstream vortss, tracerss;
            vortss << t << "_vort";
            tracerss << t << "_tracer";
            X::GNUPLOT::output_field(vortss.str().c_str(), f[DD(vort_output)].getPtr(), x.getPtr(), y.getPtr(), D0, D1);
//            X::GNUPLOT::output_field(tracerss.str().c_str(), f[DD(tracer_output)].getPtr(), x.getPtr(), y.getPtr(), D0, D1);
        }

        cout << endl;

    }


    return 0;

}


void printr(T *nums, xsize n0, xsize n1) {
    xsize offset = 0;
    for(xsize i=0; i < n0; ++i) {
        for(xsize j=0; j < n1; ++j) {
            printf("%5.3f, ", nums[offset]);
            ++offset;
        }
        printf("\n");
    }


}
void printc(fftw_complex * nums, xsize n0, xsize n1) {
    n1 = (xsize) (n1/2 + 1);
    xsize offset = 0;
    for(xsize i=0; i < n0; ++i) {
        for(xsize j=0; j < n1; ++j) {
            printf("[%d,%d] %5.3f %+5.3fi, ",i,j, nums[offset][0], nums[offset][1]);
            ++offset;
        }
        printf("\n");
    }


}

