#include "typedef.h"
#include "dataset.h"
#include "data_index_1.h"
#include <iostream>

using namespace X;
using namespace std;

typedef float TYPE;
const xsize N1 = 5;
const xsize N2 = 3;

int main() {

    Dataset<TYPE,5> dat;//DataIndex1<TYPE,N1>,5> dat;
    cout << dat(0) << endl;

    return 0;
}
