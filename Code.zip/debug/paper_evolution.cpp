#define _USE_MATH_DEFINES
#include <cmath>

#include <fstream>
#include <iostream>

#include <string>
#include <sstream>
#include <complex>

#define X_INCLUDE_IO
#define X_INCLUDE_DIM2
#define X_INCLUDE_FFTW
#define X_INCLUDE_GNUPLOT
#define X_FFTW_MAGIC_DOUBLE
#include "xdmlab"

#define DD(x) static_cast<xsize>(DATA::x)
#define WW(x) static_cast<xsize>(WAVE::x)
#define SS(x) static_cast<xsize>(SET::x)

typedef double T;

using namespace X;
using namespace X::FFTW;
//using namespace X::GNUPLOT;
using namespace std;

const T vort_nu = 50;
const T tracer_nu = 25;
const xsize D0 = 768;
const xsize D1 = 768;
const double delta_t = 3.5;
const xsize total_time = 3600 * 1.5;
const xsize final_timestep = (xsize) (total_time/delta_t);
const xsize recording_timestep = 10;
const T L0 = 600000;
const T L1 = 600000;
const T filter0 = 256;
const T filter1 = 256;
const T filter = 256;

const xsize WAVE_TABLE_SIZE_0 = fftw_wave_table_size(0,D0,D1);
const xsize WAVE_TABLE_SIZE_1 = fftw_wave_table_size(1,D0,D1);
enum class DATA : xsize {
    r=0, alpha, 
    vort, vortgdx, vortgdy, u, v, vortlap, vort_nonlin, vort_output,
    tracer, tracergdx, tracergdy, tracerlap, tracer_nonlin, tracer_output,
    SIZE
};

enum class WAVE : xsize {
    vort = 0, stream, u, v, vortgdx, vortgdy, vortlap, vorttmp, vort_nonlin, q1, q2, q3, q4, vort_output, 
    tracer, tracergdx, tracergdy, tracerlap, tracertmp, tracer_nonlin, tracer_q1, tracer_q2, tracer_q3, tracer_q4, tracer_output,
    nonlin_mask, wvn, dealiasing_mask,
    SIZE
};

//const xsize WAVETABLESIZE = fftw_wave_table_size(D0,D1);


enum class RK4_STAGE : xsize { s1, s2, s3, s4 };

//void printr(T * nums, xsize n0, xsize n1);
//void printc(fftw_complex * nums, xsize n0, xsize n1);

typedef DataIndex2<T,D0,D1> MyData;
typedef DataIndex1<DataIndex2<T,D0,D1>,2> MyGrid;

int main() {
    cout << "# Program start" << endl << flush;

    Enumerator2<D0,D1> enu_data;
    Enumerator2<WAVE_TABLE_SIZE_0, WAVE_TABLE_SIZE_1> enu_wave;
    DataIndex1<T,D0> x;
    DataIndex1<T,D1> y;
    
    MyGrid xxyy;
    Util::linspace2(x, (T)0, L0);
    Util::linspace2(y, (T)0, L1);
    Util::set2DMeshgrid(xxyy(0), xxyy(1), x, y);

    // Making field
    Field< MyData, MyGrid, D0*D1, DD(SIZE)> f;
    (f.getGrid())(0).copyData(xxyy(0)); 
    (f.getGrid())(1).copyData(xxyy(1));

    T step0 = (2 * M_PI) / D0;
    T step1 = (2 * M_PI) / D1;

    cout << "Setting vorticity... " << flush;

    T centx = L0/2;
    T centy = L1/2;

    enu_data.each_index([&] (xsize i, xsize j) {
        f[DD(r)](i,j) = sqrt( pow(f.getGrid()(0)(i,j) - centx,2) + pow(f.getGrid()(1)(i,j) - centy, 2));
    });

    cout << "Setting vorticity... " << flush;
    
    T epsilon = 0.7;
    T lambda = 2.0;
    T r_i = 30000;
    T r_o = 60000;
    T lim0 = 1 - pow(epsilon,2);
    T zeta0 = 0.005;
    enu_data.each_index([&] (xsize i, xsize j) {
            T dx = f.getGrid()(0)(i,j) - centx;
            T r = f[DD(r)](i,j);


            // to prevent r = 0 situation
            if ( r < lim0 ) {
                f[DD(vort)](i, j) = zeta0;
                return;
            }


            T alpha = (1 - pow(epsilon,2)) / sqrt( 1 - pow( epsilon * dx/r, 2));

            if(r < r_i * alpha) {
                f[DD(vort)](i, j) = zeta0;
                return;
            } else if(r > r_o * alpha) {
                f[DD(vort)](i, j) = 0;
                return;
            }


            T r_prime = (r/alpha - r_i) / (r_o - r_i);
            f[DD(vort)](i, j) = zeta0 * (1 - exp(- (lambda / r_prime) * exp (1/(r_prime - 1))));
            
    });

    cout << "done." << endl << flush;
    cout << "Setting tracer... " << flush;
    // setting tracer
    T r_a = 50000;
    T c_0 = 1000;
    enu_data.each_index([&] (xsize i, xsize j) {
            T r = f[DD(r)](i,j);
            f[DD(tracer)](i,j) = c_0 * exp(-pow(r/r_a,2)) ;
    });

    cout << "done." << endl << flush;

    string vort_filename("init_vort");
    string tracer_filename("init_tracer");
    GNUPLOT::output_field(vort_filename.c_str(), f[DD(vort)].getDataPointer(), x.getDataPointer(), y.getDataPointer(), D0, D1);
    GNUPLOT::output_field(tracer_filename.c_str(), f[DD(tracer)].getDataPointer(), x.getDataPointer(), y.getDataPointer(), D0, D1);

    
    cout << "Setting wavetable... " << flush;

    Dataset<DataIndex2<FFTW_COMPLEX, WAVE_TABLE_SIZE_0, WAVE_TABLE_SIZE_1>, WW(SIZE)> w;
    enu_wave.each_index([&](xsize i, xsize j) {
        w[WW(wvn)](i,j)[0] = fftw_map_wavenumber(D0,i);
        w[WW(wvn)](i,j)[1] = fftw_map_wavenumber(D1,j); 
    });
    
    cout << "Making fftw plans... " << flush;
    // fftw plans
    // vort
    fftw_plan vort_sink =        fftw_plan_dft_r2c_2d(D0, D1, f[DD(vort)].p(),  w[WW(vort)].p(), FFTW_ESTIMATE);
    fftw_plan vort_nonlin_sink = fftw_plan_dft_r2c_2d(D0, D1, f[DD(vort_nonlin)].p(),  w[WW(vort_nonlin)].p(), FFTW_ESTIMATE);
    
    fftw_plan vortgdx_rise =     fftw_plan_dft_c2r_2d(D0, D1, w[WW(vortgdx)].p(), f[DD(vortgdx)].p(), FFTW_ESTIMATE);
    fftw_plan vortgdy_rise =     fftw_plan_dft_c2r_2d(D0, D1, w[WW(vortgdy)].p(), f[DD(vortgdy)].p(), FFTW_ESTIMATE);
    fftw_plan u_rise =           fftw_plan_dft_c2r_2d(D0, D1, w[WW(u)].p(),       f[DD(u)].p(), FFTW_ESTIMATE);
    fftw_plan v_rise =           fftw_plan_dft_c2r_2d(D0, D1, w[WW(v)].p(),       f[DD(v)].p(), FFTW_ESTIMATE);
    fftw_plan vort_output_rise = fftw_plan_dft_c2r_2d(D0, D1, w[WW(vort_output)].p(),    f[DD(vort_output)].p(), FFTW_ESTIMATE);

    // fftw plans
    // tracer
    fftw_plan tracer_sink        = fftw_plan_dft_r2c_2d(D0, D1, f[DD(tracer)].p(),  w[WW(tracer)].p(), FFTW_ESTIMATE);
    fftw_plan tracer_nonlin_sink = fftw_plan_dft_r2c_2d(D0, D1, f[DD(tracer_nonlin)].p(),  w[WW(tracer_nonlin)].p(), FFTW_ESTIMATE);
    
    fftw_plan tracergdx_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracergdx)].p(), f[DD(tracergdx)].p(), FFTW_ESTIMATE);
    fftw_plan tracergdy_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracergdy)].p(), f[DD(tracergdy)].p(), FFTW_ESTIMATE);
    fftw_plan tracerlap_rise     = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracerlap)].p(), f[DD(tracerlap)].p(), FFTW_ESTIMATE);
    fftw_plan tracer_output_rise = fftw_plan_dft_c2r_2d(D0, D1, w[WW(tracer_output)].p(),    f[DD(tracer_output)].p(), FFTW_ESTIMATE);

    cout << "done." << endl << flush;
    
    // filter
    cout << "Setting de-aliasing filter... " << flush;
    enu_wave.each_index([&](xsize i, xsize j) {        
            T k = w[WW(wvn)](i,j)[0];
            T l = w[WW(wvn)](i,j)[1];
            
            if(sqrt(k*k + l*l) > filter) {
                setComplex(w[WW(dealiasing_mask)](i,j), 0, 0);
            } else {
                setComplex(w[WW(dealiasing_mask)](i,j), 1, 0);
            }
    });
    cout << "done." << endl << flush;


    // Evolution starts ~~
    
    fftw_execute(vort_sink);

    xsize rk4_counter_vort, rk4_counter_tracer;
    T sum_vort = 0;
    T sum_tracer = 0;
    cout << "Entering for loop" << endl << flush;

    for(xsize timestep = 1; timestep <= final_timestep; ++ timestep ) {
        cout << "timestep : " << ( timestep * delta_t ) << ". " << flush;
        sum_vort = 0;
        sum_tracer = 0;

        // First, copy the vort to tmp
        enu_wave.each_index([&] (xsize i, xsize j) { 
                setComplex(w[WW(vorttmp)](i,j), w[WW(vort)](i,j));
                setComplex(w[WW(tracertmp)](i,j), w[WW(tracer)](i,j)); 
    });
        
        for(xsize rk_stage = 0; rk_stage < 4; ++rk_stage) {

            // Getting gradient of vort
            diff2(0, 1, w[WW(vorttmp)].p(), w[WW(vortgdx)].p(), D0, D1, L0, L1);
            diff2(1, 1, w[WW(vorttmp)].p(), w[WW(vortgdy)].p(), D0, D1, L0, L1);

            // Inverse vort to get streamfunction
            laplacian(w[WW(vorttmp)].p(), w[WW(vortlap)].p(), D0, D1, L0, L1);
            ipoisson(w[WW(vorttmp)].p(), w[WW(stream)].p(), D0, D1, L0, L1);

            // Getting u,v from streamfunction
            diff2(0, 1, w[WW(stream)].p(), w[WW(v)].p(), D0, D1, L0, L1);
            diff2(1, 1, w[WW(stream)].p(), w[WW(u)].p(), D0, D1, L0, L1);

            // de-aliasing u,v,vortgdx,vortgdy
            enu_wave.each_index([&](xsize i, xsize j) {
                    if(w[WW(dealiasing_mask)](i,j)[0] == 0) {
                        setComplex(w[WW(u)](i,j),0,0);
                        setComplex(w[WW(v)](i,j),0,0);
                        setComplex(w[WW(vortgdx)](i,j),0,0);
                        setComplex(w[WW(vortgdy)](i,j),0,0);
                    }
            });
           

            // pseudo-spectral method : temporary transform back to real-space and get non-linear term.
            fftw_execute(vortgdx_rise); 
            fftw_execute(vortgdy_rise); 
            fftw_execute(u_rise); 
            fftw_execute(v_rise); 

            f[DD(vortgdx)] /= (D0*D1);
            f[DD(vortgdy)] /= (D0*D1);
            f[DD(u)]       /= (D0*D1);
            f[DD(v)]       /= (D0*D1);

            // get nonlinear term vortgdx * u + vortgdy * v   
            enu_data.each_index([&] (xsize i, xsize j) {
                    if(((pow(f[DD(u)](i,j),2) + pow(f[DD(u)](i,j),2))) > 200*200) { cout << "Warning: velocity exceeds 200 m/s" << f[DD(u)](i,j) << endl;}
                f[DD(vort_nonlin)](i,j) = - f[DD(vortgdx)](i,j) * f[DD(u)](i,j) + f[DD(vortgdy)](i,j) * f[DD(v)](i,j);
            });

            fftw_execute(vort_nonlin_sink);


            // Now we start dealing with tracer...
            //fftw_execute(tracer_sink);
            //diff2(0, 1, w[WW(tracer)].p(), w[WW(tracergdx)].p(), D0, D1, L0, L1);
            //diff2(1, 1, w[WW(tracer)].p(), w[WW(tracergdy)].p(), D0, D1, L0, L1);

            //laplacian(w[WW(tracer)].p(), w[WW(tracerlap)].p(), D0, D1, L0, L1);

            // dealiasing...
            //f[WW(tracergdx)].mulBy(f[WW(dealiasing_mask)]);
            //f[WW(tracergdy)].mulBy(f[WW(dealiasing_mask)]);
            
            //fftw_execute(tracergdx_rise);
            //fftw_execute(tracergdy_rise);

            //f[DD(tracergdx)].divBy(D0*D1);
            //f[DD(tracergdy)].divBy(D0*D1);
            
     
            // get vortgdx * u + vortgdy * v   
            //enu_data.each_index([&] (xsize i, xsize j) {
            //    f(DD(tracer_nonlin),i,j) = - f(DD(tracergdx),i,j) * f(DD(u),i,j) + f(DD(tracergdy),i,j) * f(DD(v),i,j);
            //});

            //fftw_execute(tracer_nonlin_sink);

            switch(rk_stage) {
                case 0:
                    rk4_counter_vort = WW(q1);
                    rk4_counter_tracer = WW(tracer_q1);
                    break;
                case 1:
                    rk4_counter_vort = WW(q2);
                    rk4_counter_tracer = WW(tracer_q2);
                    break;
                case 2:
                    rk4_counter_vort = WW(q3);
                    rk4_counter_tracer = WW(tracer_q3);
                    break;
                case 3:
                    rk4_counter_vort = WW(q4);
                    rk4_counter_tracer = WW(tracer_q4);
                    break;
            }


            enu_wave.each_index( [&] (xsize i, xsize j) { 
                    w[rk4_counter_vort](i,j)[0]   = w[WW(vortlap)](i,j)[0] * vort_nu - w[WW(vort_nonlin)](i,j)[0];
                    w[rk4_counter_vort](i,j)[1]   = w[WW(vortlap)](i,j)[1] * vort_nu - w[WW(vort_nonlin)](i,j)[1];

              //      w(rk4_counter_tracer](i,j)[0] = w[WW(tracerlap)](i,j)[0] * tracer_nu - w[WW(tracer_nonlin)](i,j)[0];
              //      w(rk4_counter_tracer](i,j)[1] = w[WW(tracerlap)](i,j)[1] * tracer_nu - w[WW(tracer_nonlin)](i,j)[1];
                    

                    switch(rk_stage) {
                    case 0:
                        w[WW(vorttmp)](i,j)[0] = w[WW(vort)](i,j)[0] + (delta_t/2) * w[rk4_counter_vort](i,j)[0]; 
                        w[WW(vorttmp)](i,j)[1] = w[WW(vort)](i,j)[1] + (delta_t/2) * w[rk4_counter_vort](i,j)[1]; 
    
               //         w[WW(tracertmp)](i,j)[0] = w[WW(tracer)](i,j)[0] + (delta_t/2) * w(rk4_counter_tracer](i,j)[0]; 
               //         w[WW(tracertmp)](i,j)[1] = w[WW(tracer)](i,j)[1] + (delta_t/2) * w(rk4_counter_tracer](i,j)[1]; 
                    break;
                    case 1:
                        w[WW(vorttmp)](i,j)[0] = w[WW(vort)](i,j)[0] + (delta_t/2) * w[rk4_counter_vort](i,j)[0];
                        w[WW(vorttmp)](i,j)[1] = w[WW(vort)](i,j)[1] + (delta_t/2) * w[rk4_counter_vort](i,j)[1];
                        
             //           w[WW(tracertmp)](i,j)[0] = w[WW(tracer)](i,j)[0] + (delta_t/2) * w(rk4_counter_tracer](i,j)[0]; 
             //           w[WW(tracertmp)](i,j)[1] = w[WW(tracer)](i,j)[1] + (delta_t/2) * w(rk4_counter_tracer](i,j)[1]; 
                    break;
                    case 2:
                        w[WW(vorttmp)](i,j)[0] = w[WW(vort)](i,j)[0] + delta_t * w[rk4_counter_vort](i,j)[0];
                        w[WW(vorttmp)](i,j)[1] = w[WW(vort)](i,j)[1] + delta_t * w[rk4_counter_vort](i,j)[1];
                        
            //            w[WW(tracertmp)](i,j)[0] = w[WW(tracer)](i,j)[0] + delta_t * w(rk4_counter_tracer](i,j)[0]; 
            //            w[WW(tracertmp)](i,j)[1] = w[WW(tracer)](i,j)[1] + delta_t * w(rk4_counter_tracer](i,j)[1]; 
                    break;
                    case 3:
                        w[WW(vort)](i,j)[0] +=  delta_t * ( (w[WW(q1)](i,j)[0]/6) + (w[WW(q2)](i,j)[0]/3) + (w[WW(q3)](i,j)[0]/3) + (w[WW(q4)](i,j)[0]/6) );
                        w[WW(vort)](i,j)[1] +=  delta_t * ( (w[WW(q1)](i,j)[1]/6) + (w[WW(q2)](i,j)[1]/3) + (w[WW(q3)](i,j)[1]/3) + (w[WW(q4)](i,j)[1]/6) );
                        
              //          w[WW(tracer)](i,j)[0] += delta_t * ( (w[WW(tracer_q1)](i,j)[0]/6) + (w[WW(tracer_q2)](i,j)[0]/3) + (w[WW(tracer_q3)](i,j)[0]/3) + (w[WW(tracer_q4)](i,j)[0]/6) );
              //          w[WW(tracer)](i,j)[1] += delta_t * ( (w[WW(tracer_q1)](i,j)[1]/6) + (w[WW(tracer_q2)](i,j)[1]/3) + (w[WW(tracer_q3)](i,j)[1]/3) + (w[WW(tracer_q4)](i,j)[1]/6) );
                    break;
                    }

            }); 
        }


//        cout << " sum of vort = " << sum_vort << ", sum of tracer = " << sum_tracer; 
        if(timestep % recording_timestep == 0) {
            // Transform back
            enu_wave.each_index( [&] (xsize i, xsize j) {
                setComplex(w[WW(vort_output)](i,j), w[WW(vort)](i,j));
            });
 
 //           enu_wave.each_index( [&] (xsize i) {
 //               w[WW(tracer_output)](i,j)[0] = w[WW(tracer)](i,j)[0];
 //               w[WW(tracer_output)](i,j)[1] = w[WW(tracer)](i,j)[1];
//            });
            
            fftw_execute(vort_output_rise);
//            fftw_execute(tracer_output_rise);
            f[DD(vort_output)]/=(D0*D1);
//            f[DD(tracer_output)].divBy(D0*D1);
//
            T sum_vort = 0;
            enu_data.each_index([&] (xsize i, xsize j){
                sum_vort += f[DD(vort_output)](i,j);
            });
            cout << "sum of vort : " << sum_vort << endl;
            int t = timestep * delta_t;
            cout << "   Recording...";
            std::stringstream vortss, tracerss;
            vortss << t << "_vort";
            tracerss << t << "_tracer";
            X::GNUPLOT::output_field(vortss.str().c_str(), f[DD(vort_output)].p(), x.p(), y.p(), D0, D1);
//            X::GNUPLOT::output_field(tracerss.str().c_str(), f[DD(tracer_output)].p(), x.p(), y.p(), D0, D1);
        }

        cout << endl;

    }


    return 0;

}

/*
void printr(T *nums, xsize n0, xsize n1) {
    xsize offset = 0;
    for(xsize i=0; i < n0; ++i) {
        for(xsize j=0; j < n1; ++j) {
            printf("%5.3f, ", nums[offset]);
            ++offset;
        }
        printf("\n");
    }


}
void printc(fftw_complex * nums, xsize n0, xsize n1) {
    n1 = (xsize) (n1/2 + 1);
    xsize offset = 0;
    for(xsize i=0; i < n0; ++i) {
        for(xsize j=0; j < n1; ++j) {
            printf("[%d,%d] %5.3f %+5.3fi, ",i,j, nums[offset][0], nums[offset][1]);
            ++offset;
        }
        printf("\n");
    }


}
*/
